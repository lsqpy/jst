<?php
define('APP_DEBUG',true);
//定义项目名称
define("APP_NAME","App");
//定义项目路径
define("APP_PATH","./App/");
//更改文件目录
define('RUNTIME_PATH','./Temp/');
//加载框架入口文件
require "./ThinkPHP/ThinkPHP.php";

?>