<?php
$db_config = include './config.inc.php';
return $db_config;
?>