<?php
// 本类由系统自动生成，仅供测试用途
class ExperienceAction extends Action {
    public function design(){
	    $this->display();
    }
    
    
    public function performance(){
	    $this->display();
    }
    
    
    
    public function functions(){
	    $this->display();
    }
}